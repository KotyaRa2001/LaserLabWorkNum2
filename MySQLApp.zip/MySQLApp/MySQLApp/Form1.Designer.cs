﻿
namespace MySQLApp
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.loadButtom = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.saveButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.serverString = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.databaseString = new System.Windows.Forms.TextBox();
            this.userString = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.passwordString = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tableString = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.findTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.findButton = new System.Windows.Forms.Button();
            this.buyerBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.productBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.countBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.executeButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // loadButtom
            // 
            this.loadButtom.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.loadButtom.Location = new System.Drawing.Point(335, 306);
            this.loadButtom.Name = "loadButtom";
            this.loadButtom.Size = new System.Drawing.Size(198, 58);
            this.loadButtom.TabIndex = 0;
            this.loadButtom.Text = "Load";
            this.loadButtom.UseVisualStyleBackColor = true;
            this.loadButtom.Click += new System.EventHandler(this.loadButtom_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(264, 15);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(684, 281);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // saveButton
            // 
            this.saveButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.saveButton.Location = new System.Drawing.Point(667, 306);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(198, 58);
            this.saveButton.TabIndex = 2;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Server";
            // 
            // serverString
            // 
            this.serverString.Location = new System.Drawing.Point(83, 15);
            this.serverString.Name = "serverString";
            this.serverString.Size = new System.Drawing.Size(100, 20);
            this.serverString.TabIndex = 4;
            this.serverString.Text = "localhost";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Database";
            // 
            // databaseString
            // 
            this.databaseString.Location = new System.Drawing.Point(83, 45);
            this.databaseString.Name = "databaseString";
            this.databaseString.Size = new System.Drawing.Size(100, 20);
            this.databaseString.TabIndex = 6;
            this.databaseString.Text = "labworkn2";
            // 
            // userString
            // 
            this.userString.Location = new System.Drawing.Point(83, 79);
            this.userString.Name = "userString";
            this.userString.Size = new System.Drawing.Size(100, 20);
            this.userString.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "User";
            // 
            // passwordString
            // 
            this.passwordString.Location = new System.Drawing.Point(83, 113);
            this.passwordString.Name = "passwordString";
            this.passwordString.PasswordChar = '*';
            this.passwordString.Size = new System.Drawing.Size(100, 20);
            this.passwordString.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Password";
            // 
            // tableString
            // 
            this.tableString.Location = new System.Drawing.Point(83, 144);
            this.tableString.Name = "tableString";
            this.tableString.Size = new System.Drawing.Size(100, 20);
            this.tableString.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Table";
            // 
            // findTextBox
            // 
            this.findTextBox.Location = new System.Drawing.Point(87, 207);
            this.findTextBox.Name = "findTextBox";
            this.findTextBox.Size = new System.Drawing.Size(100, 20);
            this.findTextBox.TabIndex = 14;
            this.findTextBox.TextChanged += new System.EventHandler(this.findTextBox_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(80, 181);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Query";
            // 
            // findButton
            // 
            this.findButton.Location = new System.Drawing.Point(15, 207);
            this.findButton.Name = "findButton";
            this.findButton.Size = new System.Drawing.Size(54, 23);
            this.findButton.TabIndex = 15;
            this.findButton.Text = "Find";
            this.findButton.UseVisualStyleBackColor = true;
            this.findButton.Click += new System.EventHandler(this.findButton_Click);
            // 
            // buyerBox
            // 
            this.buyerBox.Location = new System.Drawing.Point(87, 311);
            this.buyerBox.Name = "buyerBox";
            this.buyerBox.Size = new System.Drawing.Size(100, 20);
            this.buyerBox.TabIndex = 21;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 314);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "Buyer";
            // 
            // productBox
            // 
            this.productBox.Location = new System.Drawing.Point(87, 246);
            this.productBox.Name = "productBox";
            this.productBox.Size = new System.Drawing.Size(100, 20);
            this.productBox.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 249);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 18;
            this.label8.Text = "Product";
            // 
            // countBox
            // 
            this.countBox.Location = new System.Drawing.Point(87, 280);
            this.countBox.Name = "countBox";
            this.countBox.Size = new System.Drawing.Size(100, 20);
            this.countBox.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 283);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Count";
            // 
            // executeButton
            // 
            this.executeButton.Location = new System.Drawing.Point(15, 341);
            this.executeButton.Name = "executeButton";
            this.executeButton.Size = new System.Drawing.Size(172, 23);
            this.executeButton.TabIndex = 22;
            this.executeButton.Text = "Execute";
            this.executeButton.UseVisualStyleBackColor = true;
            this.executeButton.Click += new System.EventHandler(this.executeButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 385);
            this.Controls.Add(this.executeButton);
            this.Controls.Add(this.buyerBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.productBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.countBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.findButton);
            this.Controls.Add(this.findTextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tableString);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.userString);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.passwordString);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.databaseString);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.serverString);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.loadButtom);
            this.Name = "Form1";
            this.Text = "MySQLApp";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.resizeContent);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button loadButtom;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox serverString;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox databaseString;
        private System.Windows.Forms.TextBox userString;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox passwordString;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tableString;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox findTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button findButton;
        private System.Windows.Forms.TextBox buyerBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox productBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox countBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button executeButton;
    }
}

